# FORSEN PLEBLIST ARCHIVE

## streams.json

`streams.json` contains a list of all streams

`id` the database ID of the stream  
`title` the title of the stream  

## stream-chunks.json

`stream-chunks.json` contains a list of stream chunks. a stream chunk is a segment of a stream. if forsen went offline then online quickly, it'll still just count as a single stream for the purpose of the recordkeeping, stream chunks keeps start/stop times of each chunk and the twitch thumbnail

## songs.json

`songs.json` contains a list of each song request, when it was added, and which stream it was requested in.

`stream_id` the id of stream this song was requested in (match with `streams.json` `id`)  
`youtube_id` the ID of the youtube song, so if you go to `https://youtu.be/$youtube_id` you'll find the requested song  

## song-info.json

`song-info.json` contains a list of cached titles, thumbnails, durations of each song requested through the pleblist.

`pleblist_song_youtube_id` the youtube ID (match with `songs.json` `youtube_id`)  
`title` title of the youtube video (at the time it was last played)  
